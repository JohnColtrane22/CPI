import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
  
  def Message getLocationURL(Message message) {
    def map = message.getProperties();
    def dfHostName = map.get("Dayforce_HOSTNAME")
    def httpMethod = "GET" //define the Method  that best suite for you
    def originalUrl = dfHostName+'/api/Hatch/v1/Employees/00000' //define the URL that best suite for you
    
    //create a new HTTP connection
	HttpURLConnection conn = new URL(originalUrl).openConnection();
	conn.setInstanceFollowRedirects(false); //disable the Follow redirect so we can get the Location Value
	conn.requestMethod = httpMethod; 

	if(conn.responseCode in [301,302,307,308]) { //Redirects error involves the enxt HTTP codes 301,302,307,308
		if (conn.headerFields.'Location') {
		  def targetUrl = conn.headerFields.Location.first(); //get the Location Value
		  def to = targetUrl.indexOf("api")
	      targetURL = targetUrl.substring(0,to)
          message.setProperty("DFtargetUrl",targetURL) //Save the Redirect URL in a property to be used afterward in the Request-Reply steps within your IFLOW
		 
		}
		else {
			throw new RuntimeException('Failed to retrive target URL');
		}
	}
	return message;
  }