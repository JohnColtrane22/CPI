package src.main.resources.script

class GlobalDefinitions{
    
    static String FUNCTIONAL_SUBJECT_PREFIX = 'CI NOTIFICATION -';       // Functional Email Subject
    static String TECHNICAL_SUBJECT_PREFIX = 'CI NOTIFICATION ERROR -'; // Techical Email Subject
    

    
    //errors
    static String noDataFromSuccessFactorsException = 'No data found from Success Factors'
    static String noResponseFromTargetException = 'No response from Target System'
    
    
    

    static String getFunctionalSubject(String title){
        return this.FUNCTIONAL_SUBJECT_PREFIX + title;
    }
    
    static String getTechnicalSubject(String title){
        return this.TECHNICAL_SUBJECT_PREFIX + title;
    }
    
    
    static String FUNCTIONAL_BODY = '''<!DOCTYPE html>
                                    <html>
                                    
                                    <head>
                                        <h1>SAP Cloud Integration</h1>
                                        <h2>Data Replication Monitoring</h2>
                                    </head>
                                    
                                    <body>
                                        </br>
                                        </br>
                                        <i style="color:#000000;font-size:15px">Dear SuccessFactors Customer,</i>
                                        </br>
                                        </p>
                                        <i style="color: black ;font-size:15px">This email is to notify you that the integration: ##iflowName## between ##SENDER## and ##RECEIVER## has been executed. 
                                            Details of the execution can be found in the attached file.</i>
                                        </br>
                                        </p>
                                        <i style="color: black;font-size:15px">Please find the details of the run in the table below.</i></br>
                                        </p>
                                        <i style="color:#000000;font-size:16px">Thanks & Regards,</i>
                                        </br><i style="color:#000000;font-size:16px">Signature.</i>
                                        </br>
                                        </br>
                                        <a href="">SAP Cloud Integration Monitor</a>
                                        </br>
                                        </br>
                                        <table style="width:90%">
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>CPI Tenant:</b></td>
                                                <td>##cpiEnv##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Date & Time:</b></td>
                                                <td>##date## ##time##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Message ID:</b></td>
                                                <td>##processId##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Integration Flow Name:</b></td>
                                                <td>##camelId##</td>
                                            </tr>
                                        </table>
                                        </br>
                                        </br>
                                    </body>
                                    <p>Regards,<br />TSP Integration Development Team</p>
                                    
                                    </html>'''
    
    
    
    static String TECHNICAL_BODY = '''<html>
                            <header>
                                <h1>SAP Cloud Integration</h1>
                                <h3>Data Replication Monitoring</h3>
                            </header>
                            
                            <body></br></br><i style="color:#000000;font-size:15px">Dear SuccessFactors Customer,</i></br>
                                <p /><i style="color: black ;font-size:15px">This email is to notify you that technical errors have occurred during the execution of the following integration:
                                    ##iflowName## between the ##SENDER## and ##RECEIVER## system. The attached file contains the details of the
                                    the execution.</br>
                                    <p /><i style="color: black;font-size:15px">Please find the details of the run in the table below. </br>
                                        <p /><i style="color:#000000;font-size:16px">Thanks & Regards,</i></br><i
                                            style="color:#000000;font-size:16px">Signature.</i></br></br><a href="">SAP Cloud Integration
                                            Monitor</a></br></br>
                                        <table style="width:90%">
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>CPI Tenant:</b></td>
                                                <td>##cpiEnv##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Date:</b></td>
                                                <td>##date##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Time:</b></td>
                                                <td>##time##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Message ID:</b></td>
                                                <td>##processId##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Integration Flow Name:</b></td>
                                                <td>##camelId##</td>
                                            </tr>
                                            <tr>
                                                <td style="background-color:#116891;color:white"><b>Exception Message:</b></td>
                                                <td>##exceptionMessage##</td>
                                            </tr>
                                        </table></br></br>
                            </body>
                            <p>Regards,<br />TSP Integration Development Team</p>
                            
                            </html>'''
                            
        static String TECHNICAL_BODY_V2 = '''<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="x-apple-disable-message-reformatting">

    <style>
        table,
        td,
        div,
        h1,
        p {
            font-family: Arial, sans-serif;
        }
    </style>
</head>

<body style="margin:0;padding:0;">
    <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:#ffffff;">
        <tr>
            <td align="center" style="padding:0;">
                <table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;">
                    <tr>
                        <td align="center" style="padding:10px 0 10px 0;background:#fff;">
                            <div style="height:120px; width:100%; background:#0F5580;font: bold 100px 'Trebuchet MS'; color:white;letter-spacing: -5px ">
                                M&H CI LOG
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:36px 30px 42px 30px;">
                            <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;">
                                <tr>
                                    <td style="padding:0 0 36px 0;color:#153643;">
                                        <h1 style="font-size:24px;margin:0 0 20px 0;font-family:Arial,sans-serif;">ERROR IN CPI</h1>
                                        <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Hi Team,<br>
                                            <br/> This email is to notify you that technical errors have occurred during the execution of the following integration: ##iflowName## between the ##SENDER## and ##RECEIVER## system. The attached file contains
                                            the details of the the execution.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:0;">
                                        <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;">
                                            <tr>
                                                <td style="width:130px;padding:0;vertical-align:top;color:#153643;">
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">CPI Tenant&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Interface Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Date&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Time&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Process ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</p>
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Exception Message&nbsp;&nbsp;:</p>
                                                    </p>
                                                </td>
                                                <td style="width:20px;padding:0;font-size:0;line-height:0;">&nbsp;</td>
                                                <td style="width:260px;padding:0;vertical-align:top;color:#153643;">
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##cpiEnv##
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##camelId##
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##date##
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##time##
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##processId##
                                                    </p>
                                                    <p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">##exceptionMessage##
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
                                            Please contact support Team if you need assistance.
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:15px;background:#A9A9A9;">
                            <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:12px;font-family:Arial,sans-serif;">
                                <tr>
                                    <td style="padding:0;width:50%;" align="left">
                                        <p style="margin:0;font-size:12px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;">
                                            &reg; The Silicon Partners Inc. <br />
                                        </p>
                                    </td>
                                    <td style="padding:0;width:50%;" align="right">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>'''
                            
       
}
