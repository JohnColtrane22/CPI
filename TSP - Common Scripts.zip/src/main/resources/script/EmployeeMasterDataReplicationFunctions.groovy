import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import src.main.resources.script.Email;
import groovy.xml.*;


def Message processData(Message message) {
    //Body
    def body = message.getBody();
    message.setBody(body + " Body is modified");
    //Headers
    def headers = message.getHeaders();
    def value = headers.get("oldHeader");
    message.setHeader("oldHeader", value + " modified");
    message.setHeader("newHeader", "newHeader");
    //Properties
    def properties = message.getProperties();
    value = properties.get("oldProperty");
    message.setProperty("oldProperty", value + " modified");
    message.setProperty("newProperty", "newProperty");
    return message;
}

def Message setUpEmail(Message message){
    
    def map = message.getHeaders();
    def sender = map.get("sender");
    def receiver = map.get("receiver");
    def emailType = map.get("type");
    def camelId = map.get("camelId");
    def processId = map.get("processId");
    def iflowName = map.get("iflowName");
    def cpiEnv = map.get("cpiEnv")
    def exceptionMessage = map.get("exceptionMessage")
    
    
    def email = null;
    email = new Email(cpiEnv, camelId, processId, iflowName);
    
    if(emailType == "functional"){
        email.setFunctionalBody(sender, receiver);
    }else{
        email.setTechnicalBody(sender, receiver, exceptionMessage);
    }
    
    
    message.setProperty("EmailBody", email.getBody());
    message.setProperty("EmailSubject", email.getSubject());
    
    return message;
    
}


def Message getExceptionMessage(Message message){
    
    // get a map of properties
    def map = message.getProperties();
    
    def iflowStep =  map.get("iflowStep")
    
    // get an exception java class instance
    def ex = map.get("exception");
    if (ex!=null) {
                    
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                        
                        // Set the Event Name
                        eventNameText = "Replication Failed during " + iflowStep;
                        message.setHeader("eventName",eventNameText);
                        // copy the value of http error code (i.e. 500) to a property
                        statusCode = "HTTP Error " + ex.getStatusCode() + " " + ex.getStatusText();
                        message.setHeader("eventDesc",statusCode);
                        // copy the value of http error text (i.e. "Internal Server Error") to a property
                        message.setHeader("eventAttribName","Description");
                        message.setHeader("eventAttribValue",ex.getStatusText());
        }
        else {
                        // copy the http error response to an exchange property
                        eventNameText = "Replication Failed During " + iflowStep;
                        message.setHeader("eventName",eventNameText);
                        // copy the value of http error code (i.e. 500) to a property
                        message.setHeader("eventDesc",ex.message);
                        // copy the value of http error text (i.e. "Internal Server Error") to a property
                        message.setHeader("eventAttribName","Description");
                        message.setHeader("eventAttribValue",ex.getMessage());
        }
        
    }

    return message;
}


def Message savePayload(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    
    // Get LogLevel of the artifact
    def map        = message.getProperties();
    def logName    = map.get("logTitle");
    def logType    = map.get("logType");
    def payloadLog = map.get("PayloadLog");
    
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration");
	def logLevel  = (String) logConfig.logLevel;
	
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null && payloadLog == 'true'){
        if(logLevel.equals("DEBUG") || logLevel.equals("TRACE")) {
            messageLog.setStringProperty("Logging", "Printing Payload As Attachment");
            messageLog.addAttachmentAsString(logName, body , logType);
        } 
    }

    return message;
}