import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import src.main.resources.script.Email;
import groovy.xml.*;

def Message setUpFunctionalEmail(Message message){
    
    def properties = message.getProperties();
    String sender = properties.get("Sender");
    String receiver = properties.get("Receiver");
    
    def email = null;
    email = new Email();
    email.setFunctionalBody(sender, receiver);
    
    message.setProperty("EmailFunctionalBody", email.getBody());
    message.setProperty("FunctionalSubject", email.getSubject());
    
    return message;
    
}


def Message setUpEmail(Message message){
    
    def map = message.getHeaders();
    def sender = map.get("sender");
    def receiver = map.get("receiver");
    def emailType = map.get("type");
    
    def email = null;
    email = new Email();
    
    if(emailType == "functional"){
        email.setFunctionalBody(sender, receiver);
    }else{
        email.setTechnicalBody(sender, receiver);
    }
    
    
    message.setProperty("EmailBody", email.getBody());
    message.setProperty("EmailSubject", email.getSubject());
    
    return message;
    
}



def Message savePayload(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    
    // Get LogLevel of the artifact
    def map        = message.getProperties();
    def logName    = map.get("logTitle");
    def logType    = map.get("logType");
    def payloadLog = map.get("PayloadLog");
    
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration");
	def logLevel  = (String) logConfig.logLevel;
	
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null && payloadLog == 'true'){
        if(logLevel.equals("DEBUG") || logLevel.equals("TRACE")) {
            messageLog.setStringProperty("Logging", "Printing Payload As Attachment");
            messageLog.addAttachmentAsString(logName, body , logType);
        } 
    }

    return message;
}