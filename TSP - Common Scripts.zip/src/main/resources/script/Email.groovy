package src.main.resources.script

import src.main.resources.script.GlobalDefinitions;
import java.text.SimpleDateFormat


class Email {
    
    String body;
    String subject;
    String cpiEnv;
    String date;
    String time;
    String processId;
    String iflowName;
    String camelId;
    String exceptionMessage;
    
    
    public Email(String cpiEnv, String camelId, String processId, String iflowName) {
		super(); 
		
		def dateTime = new Date();
        def dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        def timeFormat = new SimpleDateFormat("hh:mm:ss");
        
        this.date = dateFormat.format(dateTime);
        this.time = timeFormat.format(dateTime);
        this.cpiEnv = cpiEnv;
        this.camelId = camelId;
        this.processId = processId;
        this.iflowName = iflowName;
        this.exceptionMessage = '';
        
	}

    public void setBody(String body){
        this.body = body;
    }    
    
    public String getBody(){
        return this.body;
    }
    
    public String getSubject(){
        return this.subject;
    }
    
    public void addFrom(def from){
        this.from.addAll(from);
    }

    public void replaceBody(String from, String to){
        this.body = this.body.replace(from, to);
    }
    
     public void setFunctionalBody(String sender, String receiver){
       
        this.body = GlobalDefinitions.FUNCTIONAL_BODY;
        this.subject = GlobalDefinitions.getFunctionalSubject(this.iflowName);
        
        this.replaceBody("##SENDER##", sender);
        this.replaceBody("##RECEIVER##", receiver);
        
        this.replaceBody("##camelId##", this.camelId);
        this.replaceBody("##cpiEnv##", this.cpiEnv);
        this.replaceBody("##processId##", this.processId);
        this.replaceBody("##iflowName##", this.iflowName);
        this.replaceBody("##date##", this.date);
        this.replaceBody("##time##", this.time);
    }
    
    public void setTechnicalBody(String sender, String receiver, String exceptionMessage){
        this.body = GlobalDefinitions.TECHNICAL_BODY_V2;
        this.subject = GlobalDefinitions.getTechnicalSubject(this.iflowName);
        
        this.replaceBody("##SENDER##", sender);
        this.replaceBody("##RECEIVER##", receiver);
        
        this.replaceBody("##camelId##", this.camelId);
        this.replaceBody("##cpiEnv##", this.cpiEnv);
        this.replaceBody("##processId##", this.processId);
        this.replaceBody("##iflowName##", this.iflowName);
        this.replaceBody("##date##", this.date);
        this.replaceBody("##time##", this.time);
        this.replaceBody("##exceptionMessage##", exceptionMessage);
        
        
    }
    
    
}


