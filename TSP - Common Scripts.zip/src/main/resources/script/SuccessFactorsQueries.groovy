import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message buildSFSFQuery(Message message) {
    
    //Properties
    def properties = message.getProperties();
    replicationDateTime = properties.get('LastExcecutionDateTime');
    ftsd = properties.get('FTSD');
    eventReasons = properties.get('EventReasons');
    userIds = properties.get('PersonIDs');
    iterationNum = properties.get('sap.loop.counter.CallActivity_594619');

    def v_select = "personIdExternal,countryOfBirth,dateOfBirth,perPersonUuid,personId,regionOfBirth,employmentNav/personIdExternal,employmentNav/userId,employmentNav/StockEndDate,employmentNav/assignmentClass,employmentNav/assignmentIdExternal,employmentNav/benefitsEligibilityStartDate,employmentNav/benefitsEndDate,employmentNav/bonusPayExpirationDate,employmentNav/customLong1,employmentNav/eligibleForSalContinuation,employmentNav/eligibleForStock,employmentNav/employeeFirstEmployment,employmentNav/endDate,employmentNav/firstDateWorked,employmentNav/hiringNotCompleted,employmentNav/initialOptionGrant,employmentNav/initialStockGrant,employmentNav/isContingentWorker,employmentNav/isECRecord,employmentNav/lastDateWorked,employmentNav/okToRehire,employmentNav/originalStartDate,employmentNav/payrollEndDate,employmentNav/prevEmployeeId,employmentNav/professionalServiceDate,employmentNav/regretTermination,employmentNav/salaryEndDate,employmentNav/seniorityDate,employmentNav/serviceDate,employmentNav/startDate,emailNav/emailType,emailNav/personIdExternal,emailNav/emailAddress,emailNav/isPrimary,nationalIdNav/cardType,nationalIdNav/country,nationalIdNav/personIdExternal,nationalIdNav/isPrimary,nationalIdNav/nationalId,nationalIdNav/notes,phoneNav/personIdExternal,phoneNav/phoneType,phoneNav/areaCode,phoneNav/countryCode,phoneNav/extension,phoneNav/isPrimary,phoneNav/phoneNumber,personalInfoNav/personIdExternal,personalInfoNav/startDate,personalInfoNav/attachmentId,personalInfoNav/endDate,personalInfoNav/firstName,personalInfoNav/gender,personalInfoNav/lastName,personalInfoNav/maritalStatus,personalInfoNav/middleName,personalInfoNav/namePrefix,personalInfoNav/nationality,personalInfoNav/nativePreferredLang,personalInfoNav/preferredName,personalInfoNav/salutation,employmentNav/jobInfoNav/seqNumber,employmentNav/jobInfoNav/startDate,employmentNav/jobInfoNav/userId,employmentNav/jobInfoNav/businessUnit,employmentNav/jobInfoNav/company,employmentNav/jobInfoNav/contractDate,employmentNav/jobInfoNav/contractId,employmentNav/jobInfoNav/contractNumber,employmentNav/jobInfoNav/contractType,employmentNav/jobInfoNav/costCenter,employmentNav/jobInfoNav/countryOfCompany,employmentNav/jobInfoNav/department,employmentNav/jobInfoNav/division,employmentNav/jobInfoNav/empRelationship,employmentNav/jobInfoNav/emplStatus,employmentNav/jobInfoNav/employeeClass,employmentNav/jobInfoNav/endDate,employmentNav/jobInfoNav/event,employmentNav/jobInfoNav/eventReason,employmentNav/jobInfoNav/jobCode,employmentNav/jobInfoNav/jobGroup,employmentNav/jobInfoNav/jobTitle,employmentNav/jobInfoNav/location,employmentNav/jobInfoNav/managerId,employmentNav/jobInfoNav/notes,employmentNav/jobInfoNav/payGrade,employmentNav/jobInfoNav/payScaleArea,employmentNav/jobInfoNav/payScaleGroup,employmentNav/jobInfoNav/payScaleLevel,employmentNav/jobInfoNav/position,employmentNav/jobInfoNav/positionEntryDate,employmentNav/jobInfoNav/regularTemp,employmentNav/jobInfoNav/timezone,employmentNav/jobInfoNav/workscheduleCode,employmentNav/jobInfoNav/workingDaysPerWeek,employmentNav/jobInfoNav/workerCategory";

    message.setProperty('p_select', v_select);
    
    
    def v_expand = 'employmentNav,emailNav,nationalIdNav,phoneNav,personalInfoNav,employmentNav/jobInfoNav';
    
    message.setProperty('p_expand', v_expand);
    
    if(replicationDateTime == null || replicationDateTime == '' || userIds != '' ){
        replicationDateTime = ftsd;
        replicationDateTime = ftsd + 'T00:00:00'
        replicationDateTime = replicationDateTime.replace(' ', 'T')
        replicationDateTime = replicationDateTime+'Z';
    }
    
    message.setProperty('lastExcecutionDateTime', replicationDateTime);
    
    def v_filter_lmdt = "(lastModifiedDateTime gt '"+replicationDateTime+"'"+" or emailNav/lastModifiedDateTime gt '"+replicationDateTime+"'"+" or nationalIdNav/lastModifiedDateTime gt '"+replicationDateTime+"'"+" or personalInfoNav/lastModifiedDateTime gt '"+replicationDateTime+"'"+" or phoneNav/lastModifiedDateTime gt '"+replicationDateTime+"'"+" or employmentNav/lastModifiedDateTime gt '"+replicationDateTime+"'"+" or employmentNav/jobInfoNav/lastModifiedDateTime gt '"+replicationDateTime+"')";
    
    message.setProperty('p_filter_lmdt', v_filter_lmdt);
    
    
    def events = eventReasons.split(',').collect{it as String};
    
    def i = 1;
    def v_eventReason = '';
    for(String event in events) { 
        if(i == 1){
            v_eventReason = " and (employmentNav/jobInfoNav/eventReason eq '" + event + "'";
        }
        if(i != 1){
            v_eventReason = v_eventReason + " or employmentNav/jobInfoNav/eventReason eq '" + event + "'";
        }
        if(events.size() == i){
            v_eventReason = v_eventReason + ")";
        }
        i = i + 1;
    } 
    
    message.setProperty('p_filter_eventReason', v_eventReason);
    
    
    def ids = userIds.split(',').collect{it as String};
    
    def v_personIdExternal = '';
    i = 1;
    for(String id in ids) { 
        if(i == 1){
            v_personIdExternal = " and (personIdExternal eq '" + id + "'";
        }
        if(i != 1){
            v_personIdExternal = v_personIdExternal + " or personIdExternal eq '" + id + "'";
        }
        if(ids.size() == i){
            v_personIdExternal = v_personIdExternal + ")";
        }
        i = i + 1;
    }
    
    message.setProperty('filterPersonIdExternals', v_personIdExternal);
    
    def query = '$select=' + v_select + '&$expand=' + v_expand + '&$filter=' + v_filter_lmdt + v_eventReason + v_personIdExternal
    
    message.setProperty('query', query);
    
    return message;
    
}
