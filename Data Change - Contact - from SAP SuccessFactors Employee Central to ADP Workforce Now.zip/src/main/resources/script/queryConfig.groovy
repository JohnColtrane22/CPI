import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Date;


def Message buildSFSFQuery(Message message) {
    
    //Properties
    def properties = message.getProperties();
    replicationDateTime = properties.get('LastExecutionDateTime');
    ftsd = properties.get('FTSD');
    customFromDate = properties.get('CustomFromDate');
    userIds = properties.get('PersonIDs');
    userIdsExclude = properties.get('PersonIDsExclude');
    iterationNum = properties.get('sap.loop.counter.CallActivity_594619');

	def v_select = [
		"personId",
		"personIdExternal",
		"customString2",
		"personalInfoNav/firstName",
		"personalInfoNav/lastName",
		"personalInfoNav/secondLastName",
		"personalInfoNav/lastModifiedDateTime",
		"nationalIdNav/cardType",
		"nationalIdNav/nationalId",
		"nationalIdNav/lastModifiedDateTime",
		"homeAddressNavDEFLT/startDate",
		"homeAddressNavDEFLT/endDate",
		"homeAddressNavDEFLT/lastModifiedDateTime",
		"homeAddressNavDEFLT/address1",
		"homeAddressNavDEFLT/address2",
		"homeAddressNavDEFLT/address3",
		"homeAddressNavDEFLT/zipCode",
		"homeAddressNavDEFLT/city",
		"homeAddressNavDEFLT/county",
		"homeAddressNavDEFLT/country",
		"homeAddressNavDEFLT/addressType",
		"homeAddressNavDEFLT/stateNav/externalCode",
		"phoneNav/lastModifiedDateTime",
		"phoneNav/areaCode",
		"phoneNav/phoneNumber",
		"phoneNav/phoneTypeNav/externalCode",
		"emailNav/lastModifiedDateTime",
		"emailNav/emailAddress",
		"emailNav/emailTypeNav/externalCode",
		"employmentNav/jobInfoNav/company",
		"employmentNav/jobInfoNav/eventReason",
		"employmentNav/jobInfoNav/lastModifiedDateTime",
		"employmentNav/jobInfoNav/customString10Nav/externalCode",
		"employmentNav/jobInfoNav/companyNav/name"
	].join(",");

    message.setProperty('p_select', v_select);
    
    
	def v_expand = [
		"personalInfoNav",
		"nationalIdNav",
		"homeAddressNavDEFLT/stateNav",
		"phoneNav/phoneTypeNav",
		"emailNav/emailTypeNav",
		"employmentNav/jobInfoNav/customString10Nav",
		"employmentNav/jobInfoNav/companyNav"
	].join(",");
    
    message.setProperty('p_expand', v_expand);
    
    def v_fromDate;
    def datePattern = "yyyy-MM-dd";
    def dateTimePattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    if(replicationDateTime == null || replicationDateTime == '' || userIds != '' ){
        replicationDateTime = ftsd;
        replicationDateTime = ftsd + 'T00:00:00.000'
        replicationDateTime = replicationDateTime.replace(' ', 'T')
        replicationDateTime = replicationDateTime+'Z';
        if(customFromDate == null || customFromDate == ''){
            if(ftsd == '1900-01-01'){
                v_fromDate = Date.parse(datePattern, ftsd).format(datePattern);
            }else{
                v_fromDate = Date.parse(datePattern, ftsd);
                v_fromDate = v_fromDate - 1;
                v_fromDate = v_fromDate.format(datePattern);
            }
        }else{
            v_fromDate = Date.parse(datePattern, customFromDate).format(datePattern);
        }
    }else{
        if(customFromDate == null || customFromDate == ''){
            v_fromDate = Date.parse(dateTimePattern, replicationDateTime);
            v_fromDate = v_fromDate - 1;
            v_fromDate = v_fromDate.format(datePattern);
        }else{
            v_fromDate = Date.parse(datePattern, customFromDate).format(datePattern);
        }
    }
    
    message.setProperty('lastExcecutionDateTimeUsed', replicationDateTime);
    message.setHeader('lastExcecutionDateTimeUsed', replicationDateTime);
    
    replicationDateTime = "datetimeoffset'" + replicationDateTime + "'";
    
    // Filter lastModifiedDateTime and company
    def v_filter_lmdt = "(homeAddressNavDEFLT/lastModifiedDateTime gt "+replicationDateTime+" or phoneNav/lastModifiedDateTime gt "+replicationDateTime+" or emailNav/lastModifiedDateTime gt "+replicationDateTime+" or personalInfoNav/lastModifiedDateTime gt "+replicationDateTime+" or nationalIdNav/lastModifiedDateTime gt "+replicationDateTime+") and employmentNav/jobInfoNav/company in '0533','0530','0595' and employmentNav/isContingentWorker eq false";
    
    message.setProperty('p_filter_lmdt', v_filter_lmdt);
    
    if(userIdsExclude != '' && userIdsExclude != null){
        def ids = userIdsExclude.split(',').collect{it as String};
        
        def v_personIdExternal = '';
        i = 1;
        for(String id in ids) { 
            if(i == 1){
                v_personIdExternal = "(personIdExternal ne '" + id + "'";
            }
            if(i != 1){
                v_personIdExternal = v_personIdExternal + " or personIdExternal ne '" + id + "'";
            }
            if(ids.size() == i){
                v_personIdExternal = v_personIdExternal + ")";
            }
            i = i + 1;
        }
    
         message.setProperty('filterPersonIdExternals', v_personIdExternal);
   
        def query = 'fromDate=' + v_fromDate + '&$select=' + v_select + '&$expand=' + v_expand + '&$filter=' + v_filter_lmdt + " and " + v_personIdExternal
         message.setProperty('query', query);
        
    }else if(userIds != ''){
        def ids = userIds.split(',').collect{it as String};
        
        def v_personIdExternal = '';
        i = 1;
        for(String id in ids) { 
            if(i == 1){
                v_personIdExternal = "(personIdExternal eq '" + id + "'";
            }
            if(i != 1){
                v_personIdExternal = v_personIdExternal + " or personIdExternal eq '" + id + "'";
            }
            if(ids.size() == i){
                v_personIdExternal = v_personIdExternal + ")";
            }
            i = i + 1;
        }
    
         message.setProperty('filterPersonIdExternals', v_personIdExternal);
   
        def query = 'fromDate=' + v_fromDate + '&$select=' + v_select + '&$expand=' + v_expand + '&$filter=' + v_personIdExternal
         message.setProperty('query', query);
        
    }else{
        
        def query = 'fromDate=' + v_fromDate + '&$select=' + v_select + '&$expand=' + v_expand + '&$filter=' + v_filter_lmdt
         message.setProperty('query', query);
    }
    
    return message;
    
}
