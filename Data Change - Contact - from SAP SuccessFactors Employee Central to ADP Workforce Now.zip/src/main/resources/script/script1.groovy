import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);

    //Properties
    def properties = message.getProperties();
    messages = properties.get("EM_Messages_List");
    
    def newMessages = ''
    
    if(body != null && body != ''){
        newMessages = body + messages    
    }else{
        newMessages = messages
    }
    
    
    def root = newMessages
    message.setBody(root)

    return message;
}