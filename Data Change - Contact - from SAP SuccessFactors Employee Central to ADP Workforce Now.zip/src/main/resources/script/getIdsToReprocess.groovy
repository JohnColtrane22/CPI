import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import com.sap.it.api.ITApiFactory;
import java.text.SimpleDateFormat;
import groovy.xml.*


    
def Message processData(Message message) {
    //body
    def body = message.getBody(java.io.Reader)
    def root = new XmlParser().parse(body)

    def userList = root.cust_EmployeeReplication[0].text();
    
    if(userList != null || userList.trim() != ""){
        int i = 0;
        root.cust_EmployeeReplication.each{ it ->
            if (i != 0){
             userList = it.text() + "," + userList
            }
            i++;
        }
    }
    
    
    message.setProperty("PersonIDs", userList);
    

    def sw = new StringWriter()
    def xmlNodePrinter = new XmlNodePrinter(new PrintWriter(sw))
    xmlNodePrinter.with {
        preserveWhitespace = true
    }   
    xmlNodePrinter.print(root)

    String result = sw.toString()
    message.setBody(result)

    return message;
}